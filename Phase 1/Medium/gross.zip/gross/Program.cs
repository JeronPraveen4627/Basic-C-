﻿using System;
using System.Data;
namespace total;
 class Program
 {
    public static void Main(string[] args)
    {
        double total;
        double BS=double.Parse(Console.ReadLine());
        if(BS<=10000)
        {
            double HRA=(BS*20)/100;
            double DA=(BS*80)/100;
             total=(BS+HRA+DA)*12;
            Console.WriteLine($"Annual Gross Salary: {total}");
        }
        else if(BS<=20000)
        {
            double HRA=(BS*25)/100;
            double DA=(BS*90)/100;
             total=(BS+HRA+DA)*12; 
            Console.WriteLine($"Annual Gross Salary: {total}");
        }
        else{

            double HRA=(BS*30)/100;
            double DA=(BS*95)/100;
             total=(BS+HRA+DA)*12;
            Console.WriteLine($"Annual Gross Salary: {total}");
        }
        double taxes=(total*6)/100;
        double insurence=(total*1)/100;
        double lpa=total-taxes-insurence;
       
        Console.WriteLine($"Annual Take-Home Salary: {lpa}");
    }
    }
