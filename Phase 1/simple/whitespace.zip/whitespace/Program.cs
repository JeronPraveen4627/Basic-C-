﻿using System;
namespace Whitespace;
class Program
{
    public static void Main(string[] args)
    {
        string str=Console.ReadLine();
        string str1="";
        int length=0;
        for(int i=0; i<str.Length;i++)
        {
            if(str[i]==' ')
            {
                continue;
            }
            else{
                str1=str1+str[i];
                length++;
            }
        }
            Console.WriteLine($" Modified string: {str1}");
            Console.WriteLine($" Modified string length: {length}");
        

    }
}
