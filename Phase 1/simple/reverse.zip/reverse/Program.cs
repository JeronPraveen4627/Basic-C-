﻿using System;
using System.Diagnostics;
namespace reverse;
class Program
{
    public static void Main(string[] args)
    {
        int num = int.Parse(Console.ReadLine());
        int rem=0;
        int sum=0;
        while(num>0)
        {
            rem=num%10;
            sum=sum*10+rem;
            num/=10;
        }
        Console.WriteLine(sum);
    }
}