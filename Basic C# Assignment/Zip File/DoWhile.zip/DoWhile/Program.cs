﻿using System;
using System.Runtime.InteropServices;
namespace DoWhile;

    class Program
    {
        public static void Main(string[] args)
        {
            string option = string.Empty;
            Console.Write("Enter a Number : ");
            int number ;
                do
                {
                    number=int.Parse(Console.ReadLine());
                    //Odd or even
                    if(number % 2 == 0)
                    {
                        Console.WriteLine($"{number} is even number");
                    }
                    else
                    {
                        Console.WriteLine($"{number} is odd number");
                    }

                    
                    //yes or no

                    while(true)
                    {   Console.WriteLine("Do you want to Continue? Yes/No");
                        option = Console.ReadLine();  
                        if(option.ToLower()=="yes" || option.ToLower()=="no")
                        {
                            break;
                        }
                        else
                        {
                            Console.WriteLine("Invalid , please enter a valid Input");
                        }
                    }

                }while(option == "yes" );
        }
        
    }
